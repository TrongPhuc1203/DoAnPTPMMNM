<?php
session_start();
include('config/config.php');

if (isset($_POST['dangky'])) {
    $taikhoan = $_POST['username'];
    $matkhau = $_POST['password'];
    $xacnhanmatkhau = $_POST['confirm_password'];

    if (empty($taikhoan) || empty($matkhau) || empty($xacnhanmatkhau)) {
        echo '<script>alert("Vui lòng nhập đầy đủ thông tin.");</script>';
    } elseif ($matkhau != $xacnhanmatkhau) {
        echo '<script>alert("Mật khẩu và xác nhận mật khẩu không khớp.");</script>';
    } else {
        $matkhau_ma_hoa = md5($matkhau);
        $admin_status = 1; // default status for newly registered users

        // Check if the username already exists
        $check_username_sql = "SELECT * FROM tbl_admin WHERE username='" . $taikhoan . "'";
        $check_username_result = mysqli_query($mysqli, $check_username_sql);

        if (mysqli_num_rows($check_username_result) > 0) {
            echo '<script>alert("Tài khoản đã tồn tại, vui lòng chọn tài khoản khác.");</script>';
        } else {
            // Insert new user into tbl_admin
            $register_sql = "INSERT INTO tbl_admin (username, password, admin_status) VALUES ('" . $taikhoan . "', '" . $matkhau_ma_hoa . "', '" . $admin_status . "')";
            if (mysqli_query($mysqli, $register_sql)) {
                echo '<script>alert("Đăng ký thành công.");</script>';
                header("Location: login.php");
                exit(); // exit to prevent further execution
            } else {
                echo '<script>alert("Đã có lỗi xảy ra, vui lòng thử lại.");</script>';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký tài khoản</title>
    <style type="text/css">
        body {
            background: #f2f2f2;
            font-family: Arial, sans-serif;
        }

        .wrapper-register {
            width: 30%;
            margin: 0 auto;
        }

        table.table-register {
            width: 100%;
        }

        table.table-register tr td {
            padding: 10px;
            text-align: right;
            vertical-align: top;
        }

        table.table-register tr td input[type="text"],
        table.table-register tr td input[type="password"] {
            width: 70%;
            padding: 8px;
        }

        table.table-register tr td button {
            padding: 8px 15px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        table.table-register tr td button:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: red;
            font-size: 12px;
            margin-top: 5px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            /* Thêm margin dưới cho phần tiêu đề */
        }
    </style>
</head>

<body>
    <div class="wrapper-register">
        <form action="" autocomplete="off" method="POST">
            <table border="0" class="table-register">
                <tr>
                    <td colspan="2">
                        <h1>Đăng ký tài khoản</h1>
                    </td>
                </tr>
                <tr>
                    <td>Tài khoản:</td>
                    <td><input type="text" name="username"></td>
                </tr>
                <tr>
                    <td>Mật khẩu:</td>
                    <td><input type="password" name="password"></td>
                </tr>
                <tr>
                    <td>Xác nhận mật khẩu:</td>
                    <td><input type="password" name="confirm_password"></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <button type="submit" name="dangky">Đăng ký</button>
                    </td>
                </tr>
                <?php
                if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['dangky'])) {
                    if (empty($taikhoan) || empty($matkhau) || empty($xacnhanmatkhau)) {
                        echo '<tr><td colspan="2" class="error-message">Vui lòng nhập đầy đủ thông tin.</td></tr>';
                    } elseif ($matkhau != $xacnhanmatkhau) {
                        echo '<tr><td colspan="2" class="error-message">Mật khẩu và xác nhận mật khẩu không khớp.</td></tr>';
                    }
                }
                ?>
            </table>
        </form>
    </div>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</body>

</html>
<?php
	session_start();
	include('config/config.php');
	if(isset($_POST['dangnhap'])){
		$taikhoan = $_POST['username'];
		$matkhau = md5($_POST['password']);
		$sql = "SELECT * FROM tbl_admin WHERE username='".$taikhoan."' AND password='".$matkhau."' LIMIT 1";
		$row = mysqli_query($mysqli,$sql);
		$count = mysqli_num_rows($row);
		if($count>0){
			$_SESSION['dangnhap'] = $taikhoan;
			header("Location:index.php");
		}else{
			echo '<script>alert("Tài khoản hoặc Mật khẩu không đúng,vui lòng nhập lại.");</script>';
			header("Location:login.php");
		}
	} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập Admincp</title>
    <style type="text/css">
        body {
            background: #f2f2f2;
        }
        .outer-rectangle {
            width: 320px; /* Đảm bảo khung chữ nhật lớn hơn khung tròn để bao quanh */
            margin: 0 auto;
            margin-top: 100px;
            background-color: #ffffff; /* Màu nền của khung chữ nhật */
            border: 5px solid #4682b4; /* Viền màu xanh dương */
            border-radius: 20px; /* Góc cong của khung chữ nhật */
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); /* Đổ bóng */
        }
        .wrapper-login {
            width: 300px;
            margin: 0 auto;
            background-color: #f0f8ff; /* Màu xanh nhạt của khung tròn */
            border-radius: 50%; /* Hình tròn */
            padding: 20px;
            position: relative; /* Để có thể điều chỉnh vị trí tương đối của khung tròn */
        }
        table.table-login {
            width: 100%;
        }
        table.table-login tr td {
            padding: 5px;
        }
        .btn-login {
            background-color: #008080; /* Màu xanh đậm của nút */
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<div class="outer-rectangle">
    <div class="wrapper-login">
        <form action="" autocomplete="off" method="POST">
            <table border="0" class="table-login" style="text-align: center;border-collapse: collapse;">
                <tr>
                    <td colspan="2"><h3>Đăng nhập Admin</h3></td>
                </tr>
                <tr>
                    <td>Tài khoản</td>
                    <td><input type="text" name="username"></td>
                </tr>
                <tr>
                    <td>Mật khẩu</td>
                    <td><input type="password" name="password"></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" class="btn-login" name="dangnhap" value="Đăng nhập"></td>
                </tr>
            </table>
        </form>
    </div>
</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</body>
</html>
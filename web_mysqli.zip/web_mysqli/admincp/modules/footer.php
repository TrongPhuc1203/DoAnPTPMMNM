<!-- <p>footer</p> -->
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang của tôi</title>
    <style>
        footer {
            text-align: center;
            /* Căn giữa nội dung trong footer */
        }
    </style>
</head>

<body>

    <footer>
        <p>Xem hướng dẫn từ HIEUTAN developer 2021</p>
        <p>Thiết kế website PHP thuần HTML CSS MYSQLi / Link: <a href="https://www.youtube.com/playlist?list=PLWTu87GngvNz1rTGDUdif1sk1JbZpE-m5" target="_blank">https://www.youtube.com/playlist?list=PLWTu87GngvNz1rTGDUdif1sk1JbZpE-m5</a></p>
    </footer>

</body>

</html>